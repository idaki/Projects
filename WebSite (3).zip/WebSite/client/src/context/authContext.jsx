import React, { createContext, useState, useEffect } from 'react';
import { login, logout } from '../api/auth'; // Adjust the import path as necessary

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(() => {
    const persistedAuth = localStorage.getItem('authData');
    return persistedAuth ? JSON.parse(persistedAuth) : null;
  });

  const loginHandler = async (username, password) => {
    try {
      const authData = await login(username, password);
      setAuth(authData);
    } catch (error) {
      console.error('Login failed', error);
    }
  };

  const logoutHandler = async () => {
    try {
      await logout();
      setAuth(null);
    } catch (error) {
      console.error('Logout failed', error);
    }
  };

  useEffect(() => {
    localStorage.setItem('authData', JSON.stringify(auth));
  }, [auth]);

  return (
    <AuthContext.Provider value={{ auth, loginHandler, logoutHandler }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;

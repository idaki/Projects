import React, { useState, useContext } from 'react';
import AuthContext from '../../context/authContext';
import TournamentsContainer from '../tournament-container/TournamentsContainer';
import AuthenticatedContainer from '../authenticated/AuthenticatedContainer'; // Example container for authenticated users
import PublicContainer from '../public/PublicContainer'; // Example container for public users

export default function BodyModal() {
  const { auth } = useContext(AuthContext);
  const [modal, setModal] = useState(false);

  const toggleModal = () => setModal(!modal);

  return (
    <div>
      {auth && auth.accessToken ? (
        <AuthenticatedContainer />
      ) : (
        <PublicContainer />
      )}
      <TournamentsContainer />
    </div>
  );
}

export default function PublicModal() {
    const [modal, setModal] = useState(false);
  
    const toggleModal = () => setModal(!modal);
  
    return (
      <div>
      
        <TournamentsContainer/>
        </div>
     
    );
  }
  
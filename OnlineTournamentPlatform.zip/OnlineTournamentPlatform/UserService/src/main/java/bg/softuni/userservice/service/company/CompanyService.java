package bg.softuni.userservice.service.company;


import bg.softuni.crudservice.crud.CrudService;
import bg.softuni.userservice.models.entity.business.Company;


public interface CompanyService extends CrudService<Company, Long> {

}

package bg.softuni.userservice.service.consumer;

import bg.softuni.crudservice.crud.CrudService;
import bg.softuni.userservice.models.entity.consumer.Consumer;


public interface ConsumerService extends CrudService<Consumer, Long> {



}
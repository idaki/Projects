package bg.softuni.gameservice.service;

import bg.softuni.crudservice.crud.CrudService;
import bg.softuni.gameservice.model.ExportDto.GameDTO;
import bg.softuni.gameservice.model.Game;

public interface GameService extends CrudService<Game, Long> {

    GameDTO mapToGameDTO(Game game);
}

package bg.softuni.gameservice.service;

import bg.softuni.crudservice.crud.CrudService;
import bg.softuni.gameservice.model.Asset;

public interface AssetService extends CrudService<Asset, Long> {
}

package bg.softuni.crudservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

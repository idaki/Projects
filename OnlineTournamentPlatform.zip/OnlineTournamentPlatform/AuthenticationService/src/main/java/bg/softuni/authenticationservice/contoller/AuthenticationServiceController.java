package bg.softuni.authenticationservice.contoller;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

@Controller
public class AuthenticationServiceController implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {

    }
}

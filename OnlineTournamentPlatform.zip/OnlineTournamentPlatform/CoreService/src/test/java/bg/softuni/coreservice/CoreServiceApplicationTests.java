package bg.softuni.coreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

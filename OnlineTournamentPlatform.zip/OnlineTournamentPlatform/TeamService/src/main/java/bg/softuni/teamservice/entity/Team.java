package bg.softuni.teamservice.entity;

public interface Team {
    Long getId();
    String getName();
}

import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HomePage from './pages/HomePage'; // Example home page component
import NavigationModal from './components/nav-container/NavigationContainer'; // Navigation component
import UpdatePasswordModal from './components/UpdatePasswordModal'; // Ensure correct path

function App() {
  return (
    <Router>
      <NavigationModal />
      <Switch>
        <Route path="/" exact component={HomePage} />
        {/* Define more routes as needed */}
      </Switch>
      <Route path="/update-password" component={UpdatePasswordModal} />
    </Router>
  );
}

export default App;

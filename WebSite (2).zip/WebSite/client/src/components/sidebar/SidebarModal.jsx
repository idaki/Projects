import React from 'react';
import styles from './SidebarModal.module.css';  // Ensure corresponding CSS

const SidebarModal = ({ isOpen, toggle }) => {
  return (
    isOpen && (
      <div className={`${styles.sidebar} ${styles.popup}`}>
        <nav className="nav flex-column">
          <a className={`nav-link ${styles.navLink}`} href="#"><i className="bi bi-person"></i> Profile</a>
          <a className={`nav-link ${styles.navLink}`} href="#"><i className="bi bi-gear"></i> Settings</a>
        </nav>
      </div>
    )
  );
};

export default SidebarModal;

import React from 'react';
import Profile from '../ProfileModal';

export default function AuthenticatedContainer() {
  return (
    <div>
      <Profile/>
    </div>
  );
}

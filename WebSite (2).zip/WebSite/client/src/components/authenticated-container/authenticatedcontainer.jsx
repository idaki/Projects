import React from 'react';
import Profile from '../profile/ProfileModal';

export default function AuthenticatedContainer() {
  return (
    <div>
      <Profile/>
    </div>
  );
}

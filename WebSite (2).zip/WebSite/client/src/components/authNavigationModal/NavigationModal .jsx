import React from 'react';
import styles from './NavigationModal.module.css';  // Ensure corresponding CSS

const NavigationModal = () => {
  return (
    <div className={styles.navigation}>
      <div className="nav flex-column">
        <a className="nav-link active" href="#">My Tournaments</a>
        <a className="nav-link" href="#">Friends</a>
      </div>
    </div>
  );
};

export default NavigationModal;

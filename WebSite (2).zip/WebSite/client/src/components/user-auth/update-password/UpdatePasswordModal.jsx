import React, { useState, useContext } from 'react';
import { Modal, Button, Form, Alert } from 'react-bootstrap';
import AuthContext from '../../../context/authContext'; // Adjust the import path as necessary

export default function UpdatePasswordModal({ show, handleClose }) {
  const { updatePasswordHandler } = useContext(AuthContext);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [localError, setLocalError] = useState('');

  const handleCurrentPasswordChange = (e) => {
    setCurrentPassword(e.target.value);
    if (localError) {
      setLocalError('');
    }
  };

  const handleNewPasswordChange = (e) => {
    setNewPassword(e.target.value);
    if (localError) {
      setLocalError('');
    }
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
    if (localError) {
      setLocalError('');
    }
  };

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      setLocalError('All fields are required');
      return;
    }
    if (newPassword !== confirmPassword) {
      setLocalError('New passwords do not match');
      return;
    }
    try {
      await updatePasswordHandler(currentPassword, newPassword);
      handleClose();
    } catch (err) {
      setLocalError(err.message || 'An error occurred while updating the password. Please try again.');
    }
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Update Password</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleUpdateSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Current Password</Form.Label>
            <Form.Control
              type="password"
              value={currentPassword}
              onChange={handleCurrentPasswordChange}
              isInvalid={!!localError}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>New Password</Form.Label>
            <Form.Control
              type="password"
              value={newPassword}
              onChange={handleNewPasswordChange}
              isInvalid={!!localError}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Confirm New Password</Form.Label>
            <Form.Control
              type="password"
              value={confirmPassword}
              onChange={handleConfirmPasswordChange}
              isInvalid={!!localError}
            />
          </Form.Group>

          {localError && <Alert variant="danger">{localError}</Alert>}

          <Button type="submit" variant="primary">
            Update Password
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
}

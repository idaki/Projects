const baseUrl =  'http://localhost:8080/api/tournaments';

export const getAll = async () => {
    const response = await fetch(baseUrl);
    const result = await response.json();

    const data = Object.values(result);

    return data;
};

